﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using DAL;
using System.Data;

namespace BLL
{
    /// <summary>
    /// 业务逻辑层-桥梁
    /// </summary>
    public class BLL
    {
        public static bool GetLogin(string id, string pwd)
        {
            // Login user = LoginService.GetLoginByLoginId(loginid);
            Userbook user = new Userbook();
            user = DAL.Dataacess.GetLoginByLoginId(id);
            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static DataSet FillData(string sql)
        {
            return DAL.Dataacess.GetDataSetOfSql(sql);
        }
        public static bool UpDateTable(string sql)
        {
            Dataacess dataacess = new Dataacess();
            return dataacess.UpdateDataTable(sql);
        }
    }
}
