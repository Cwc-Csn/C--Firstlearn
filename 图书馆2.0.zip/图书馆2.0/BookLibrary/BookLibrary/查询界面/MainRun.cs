﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookLibrary.查询界面
{
    public partial class MainRun : Form
    {
        public MainRun()
        {
            InitializeComponent();
            //select t.book_id,t.book_name,t.book_date,t.book_state from book_info t
            string sql = "select t.* from book_info t";
            DataSet myds = BLL.BLL.FillData(sql);
            this.dataGridView1.DataSource = myds.Tables[0];

        }

        private void MainRun_Load(object sender, EventArgs e)
        {

        }
    }
}
