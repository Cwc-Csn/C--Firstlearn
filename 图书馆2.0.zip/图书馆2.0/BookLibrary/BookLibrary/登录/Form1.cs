﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Model;
using BLL;

namespace BookLibrary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
           
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(this.txtUser.Text))
            {
                MessageBox.Show("输入用户名");
                return;
            }
            if (string.IsNullOrEmpty(this.txtPwd.Text))
            {
                MessageBox.Show("输入密码");
                return;
            }
            if (BLL.BLL.GetLogin(this.txtUser.Text.Trim()
                , this.txtPwd.Text.Trim()))
            {
                MessageBox.Show("登录成功");
                BookLibrary.查询界面.MainRun f1 = new 查询界面.MainRun();
                this.Hide();
                f1.Show();

            }
            else
            {
                MessageBox.Show("false1");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //txtUser.Focus();
        }

        private void txtUser_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                this.txtPwd.Focus();
            }
        }

        private void txtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.button1.Focus();
            }
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.button1.PerformClick();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CreatUser.CreatUser cs = new CreatUser.CreatUser();
            cs.Show();
        }
    }
}
