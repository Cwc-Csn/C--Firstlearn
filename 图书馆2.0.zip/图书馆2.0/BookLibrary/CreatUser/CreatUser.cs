﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CreatUser
{
    public partial class CreatUser : Form
    {
        public CreatUser()
        {
            InitializeComponent();
        }

        private void CreatUser_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(this.textBox1.Text.Trim()=="8888")
            {
                //MessageBox.Show("通过");
                this.Hide();
                Supervisor supervisor = new Supervisor();
                supervisor.Show();
            }
            else
            {
                MessageBox.Show("错误");
            }
        }
    }
}
