﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CreatUser
{
    public partial class Supervisor : Form
    {
        public Supervisor()
        {
            InitializeComponent();
            string sql = "select * from BOOKUSER t";
            DataSet mydataset = BLL.BLL.FillData(sql);
            this.dataGridView1.DataSource = mydataset.Tables[0];
        }

        private void Supervisor_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            this.textBox1.Text = this.dataGridView1.Rows[index].Cells[0].Value.ToString().Trim();
            //this.txtSex.Text = this.dataGridView1.Rows[index].Cells[1].Value.ToString().Trim();
            this.textBox2.Text = this.dataGridView1.Rows[index].Cells[1].Value.ToString().Trim();
            this.textBox3.Text = this.dataGridView1.Rows[index].Cells[2].Value.ToString().Trim();
            //this.txtDate.Text = this.dataGridView1.Rows[index].Cells[3].Value.ToString().Trim();
            //this.txtClass.Text = this.dataGridView1.Rows[index].Cells[4].Value.ToString().Trim();
            //this.txtState.Text = this.dataGridView1.Rows[index].Cells[5].Value.ToString().Trim();
            //this.txtSex.Text = this.dataGridView1.Rows[index].Cells[6].Value.ToString().Trim();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = this.textBox1.Text;
            string pwd = this.textBox2.Text;
            string state = this.textBox3.Text;
            string sql = "insert into bookuser values ('" + id + "','" + pwd + "','" + state + "')";
            if (BLL.BLL.UpDateTable(sql))
            {
                MessageBox.Show("添加成功", "提示", MessageBoxButtons.OK);

            }
            else
            {
                MessageBox.Show("添加失败", "提示", MessageBoxButtons.OK);

            }
            //刷新显示界面
            string breaksql = "SELECT * FROM bookuser t";
            DataSet ds = new DataSet();
            //BLL.BLL fl = new BLL.BLL();
            ds = BLL.BLL.FillData(breaksql);
            this.dataGridView1.DataSource = ds.Tables[0];

        }
    }
}
