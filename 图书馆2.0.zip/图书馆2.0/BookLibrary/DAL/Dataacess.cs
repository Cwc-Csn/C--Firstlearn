﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle;
using Oracle.ManagedDataAccess.Client;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    /// <summary>
    /// 数据访问层-数据库的交互
    /// </summary>
    public class Dataacess
    {
        # region   数据库的连接
        //数据库的连接
        private static string connString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=mcdba)));Persist Security Info=True;User ID=mclibrary;Password=mclibrary;";
        private static OracleConnection con = new OracleConnection(connString);





        #endregion
        #region   封装数据库连接，实现数据集填充数据查询
        public static DataSet GetDataSetOfSql(string sql)
        {
            //string connString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=cwc)));Persist Security Info=True;User ID=orcl;Password=cwc;";
            //OracleConnection con = new OracleConnection(connString);
            OracleDataAdapter dat = new OracleDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                dat.Fill(ds);
                return ds;
            }
            catch (OracleException ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
        #region   实现账号登录的验证
        public static Userbook GetLoginByLoginId(string id)
        {
            string sql = "select * from bookuser where id=" + id ;
            try
            {
                OracleCommand com = new OracleCommand(sql, con);
                con.Open();
                OracleDataReader reader = com.ExecuteReader();

                if (reader.Read())
                {
                    Userbook user = new Userbook();
                    user.Id = (string)reader["id"];
                    user.Pwd = (string)reader["pwd"];
                    //user.LoginPwd = (string)reader["LoginPwd"];
                    //user.StuName = (string)reader["StuName"];
                    //user.State = (Int32)reader["State"];
                    reader.Close();
                    con.Close();
                    return user;
                }
                else
                {
                    con.Close();
                    reader.Close();
                    return null;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }
        #endregion
        #region 实现数据的更新
        public   bool UpdateDataTable(string sql)
        {
            using (OracleConnection con = new OracleConnection(connString))
            {
                try
                {
                    con.Open();
                    OracleCommand cmd = new OracleCommand(sql, con);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }

            }
        }
        #endregion
    }
}
