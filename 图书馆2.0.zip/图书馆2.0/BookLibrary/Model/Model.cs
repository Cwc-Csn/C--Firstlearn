﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    /// <summary>
    /// 实体类
    /// </summary>
    public class Userbook
    {
        private string id;
        private string pwd;
        private int state;

        public string Id { get => id; set => id = value; }
        public string Pwd { get => pwd; set => pwd = value; }
        public int State { get => state; set => state = value; }
    }
}
